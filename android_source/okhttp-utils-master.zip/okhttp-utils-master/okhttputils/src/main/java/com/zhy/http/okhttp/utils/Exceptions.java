package com.zhy.http.okhttp.utils;

/**
 * Created by zhy on 15/12/14.
 */
public class Exceptions
{
    public static void illegalArgument(String msg)
    {
        throw new IllegalArgumentException(msg);
    }

}
