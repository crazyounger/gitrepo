# Bypass

Fork of the awesome markdown processor [Bypass](https://github.com/Uncodin/bypass).

## Modifications

Augmented to add:

- `TouchableUrlSpan` An extension to URLSpan which changes it's background & foreground color when
pressed.
- `FancyQuoteSpan` A quote span with a nicer presentation
- `ImageLoadingSpan` A simple text span used to mark text that will be replaced by an image once it
has been downloaded
- `LoadImageCallback` a callback mechanism for loading images
