package com.dd.morphingbutton;

public interface IProgress {
    void setProgress(int progress);
}
