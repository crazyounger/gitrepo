package com.kazy.lx;

public enum WebViewState {
    STOP, LOADING, ERROR
}
