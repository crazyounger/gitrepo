/** Automatically generated file. DO NOT MODIFY */
package com.bmob.demo.third;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}